#include <windows.h>
#include <Xinput.h>
#include <cstdio>  
#include <cmath>   
#include <iostream>

#pragma comment(lib, "Xinput9_1_0.lib") 

#define ZONAMORTA 1000

int funcaonormalizar(SHORT valorBruto)
{
    if (abs(valorBruto) < ZONAMORTA) //zona morta é o local onde os inputs são ignorados
        return 0;

    float valor = (float)valorBruto / 32767.00f;
    return (int)(valor * 1000.00f);
}

int main()
{
    XINPUT_STATE estado;
    ZeroMemory(&estado, sizeof(XINPUT_STATE)); //chamado da biblioteca XInput para zerar a memória do estado do controle

    std::cout << "MEXA OS ANALOGICOS DO CONTROLE!!!\n";
    std::cout.flush();

    while (true)
    {
        if (XInputGetState(0, &estado) == ERROR_SUCCESS)
        {
            SHORT lx = estado.Gamepad.sThumbLX; //recebe valores controle
            SHORT ly = estado.Gamepad.sThumbLY;
            SHORT rx = estado.Gamepad.sThumbRX;
            SHORT ry = estado.Gamepad.sThumbRY;

            int nlx = funcaonormalizar(lx);
            int nly = funcaonormalizar(ly);
            int nrx = funcaonormalizar(rx);
            int nry = funcaonormalizar(ry);

            std::cout << nlx << "," << nly << "," << nrx << "," << nry << "\n"; //printa os valores normalizados dos analógicos do controle
            std::cout.flush();
        }
        else
        {
            std::cout << "CONTROLE NAO CONECTADO...\n";
            std::cout.flush();
        }
        Sleep(5);
    }
    return 0;
}
