import os
import queue
import threading
import time
import customtkinter as ctk

from config import (
    ESP_IP, ESP_PORT, SOCKET_TIMEOUT, CONTROLE_EXE, CAMERA_URL,
    MAX_ROLL, MAX_PITCH, MAX_YAW, MAX_THROTTLE,
    CONTROLE_DEADZONE, CONTROLE_EXPO,
    WINDOW_W, WINDOW_H, WINDOW_TITULO, ICONE_IMG,
)  # importa as configurações personalizadas
from nucleo import ESPCom, ControleHardware, processar_dados_esp
from .tabs import TabOperacao
from .tabs.calibracao import JanelaCalibracao
from .janelaCAM import abrir_janela_camera
from .janelaGRAFICO import JanelaGraficos


# Janela principal do aplicativo. Coordena a comunicação com o ESP32, o controle físico,
# a câmera, as janelas secundárias (gráficos e calibração PID) e o processamento da telemetria.
class App:
    def __init__(self):
        # Comunicação TCP com o ESP32 e leitura do controle físico (controle.exe)
        self.esp = ESPCom(ESP_IP, ESP_PORT, SOCKET_TIMEOUT)
        self.controle = ControleHardware(CONTROLE_EXE, MAX_ROLL, MAX_PITCH, MAX_YAW,
                                         max_throttle=MAX_THROTTLE,
                                         controle_deadzone=CONTROLE_DEADZONE,
                                         controle_expo=CONTROLE_EXPO)
        self.ativo = False # True enquanto a comunicação está em andamento
        
        # Fila de telemetria: as threads de recepção colocam, a interface retira.
        # Limite de 32 itens para não crescer sem controle se a interface atrasar.
        self._fila_telemetria = queue.Queue(maxsize=32)
        self.modo_calibracao_pid = False # modo de calibração PID ligado?
        self.eixo_calibracao_pid = "X" # eixo em calibração (X, Y, Z ou ALT)
        self.altitude_pid_ativa = False # controle de altitude na operação?
        self._estado_voo = 0 # estado de voo reportado pelo ESP32

        # Referências às janelas secundárias (None quando estão fechadas)
        self._janela_graficos = None
        self._janela_calibracao_pid = None

        ctk.set_appearance_mode("Light")
        ctk.set_default_color_theme("green")

        # Janela principal
        self.window = ctk.CTk()
        self.window.title(WINDOW_TITULO)
        self.window.protocol("WM_DELETE_WINDOW", self._fechar_aplicacao)  # fechar pelo X encerra tudo

        # Controle de atualização da telemetria e da calibração do magnetômetro
        self._ultima_telemetria = 0.0 # instante da última telemetria recebida
        self._telemetria_limpa = True  # painel já foi marcado como desatualizado?
        self._calibracao_pendente = False # pedido de calibração aguardando resposta
        self._tempo_pedido_calibracao = 0.0 # quando o pedido foi feito (para timeout)
        self._status_mag_no_pedido = 0 # status do magnetômetro no momento do pedido
        self._ultimo_status_mag = 0 # último status recebido

        self._centralizar() 
        self._aplicar_icone()                               

        # Aba principal com os botões e o painel de telemetria
        self.tab_func = TabOperacao(self.window, self)
        self.tab_func.pack(fill="both", expand=True)
        # Inicia o ciclo que processa a fila de telemetria a cada 50 ms
        self.window.after(50, self._processar_fila_telemetria)

    # Centraliza a janela principal na tela, respeitando tamanhos mínimo e máximo.
    def _centralizar(self):
        lx = self.window.winfo_screenwidth()
        ly = self.window.winfo_screenheight()
        largura = min(WINDOW_W, max(640, lx - 40))
        altura = min(WINDOW_H, max(480, ly - 80))
        self.window.geometry(
            f"{largura}x{altura}+{(lx - largura)//2}+{(ly - altura)//2}"
        )

    # Aplica o ícone da aplicação, se o arquivo existir (falha silenciosa).
    def _aplicar_icone(self):
        if os.path.isfile(ICONE_IMG):
            try:
                self.window.iconbitmap(ICONE_IMG)
            except Exception:
                pass

    # ---- Comunicação Wi-Fi ----

    # Conecta ao ESP32, inicia o controle físico e as threads de envio e recepção.
    def iniciar_comunicacao(self):
        if self.ativo:
            return
        if not self.esp.conectar(forcar=True):
            print("ERRO: não foi possível conectar ao ESP32.")
            return
        # ok = sucesso; msg = texto descritivo (erro ou confirmação)
        ok, msg = self.controle.iniciar()
        if not ok:
            print(f"ERRO: {msg}")
            self.esp.fechar() # desfaz a conexão, já que o controle falhou
            return
        self.ativo = True
        # Envia ao ESP32 a configuração atual do modo PID
        self.esp.enviar_modo_pid(
            self.modo_calibracao_pid, self.eixo_calibracao_pid,
            self.altitude_pid_ativa,
        )
        print("WiFi conectado. Iniciando controle...")
        # Threads daemon: encerram junto com o programa
        threading.Thread(target=self._loop_controle, daemon=True).start()
        threading.Thread(target=self._loop_receptor, daemon=True).start()
        self._atualizar_botoes(True)

    # Encerra a comunicação na hora: desarma, fecha a conexão e o controle, e atualiza a interface.
    def finalizar_comunicacao(self):
        self.ativo = False
        self._calibracao_pendente = False
        self.esp.desarmar()
        self.esp.fechar()
        self.controle.fechar()
        print("Comunicação finalizada.")
        self._atualizar_botoes(False)
        self._atualizar_estado_janela_calibracao(False, self._estado_voo)

    # Chamado ao fechar a janela principal: faz o mesmo que finalizar_comunicacao e destrói a janela.
    def _fechar_aplicacao(self):
        self.ativo = False
        self._calibracao_pendente = False
        self.esp.desarmar()
        self.esp.fechar()
        self.controle.fechar()
        self.window.destroy()

    # Inicia o pedido de calibração do magnetômetro. Ignora se já houver um pedido em andamento.
    def iniciar_calibracao_magnetometro(self):
        if not self.ativo or self._calibracao_pendente:
            return

        self._calibracao_pendente = True
        self._tempo_pedido_calibracao = time.monotonic() # grava o momento do pedido (para timeout)
        self._status_mag_no_pedido = self._ultimo_status_mag
        self.tab_func.definir_calibracao_pendente(True) # mostra "iniciando..." no botão
        # O envio roda em outra thread para não travar a interface
        threading.Thread(target=self._enviar_pedido_calibracao, daemon=True).start()

    # Envia o comando de calibração ao ESP32 (executado em thread separada).
    def _enviar_pedido_calibracao(self):
        sucesso = self.esp.solicitar_calibracao_magnetometro()
        try:
            # Devolve o resultado para a thread principal da interface
            self.window.after(0, lambda: self._calibracao_enviada(sucesso))
        except Exception:
            pass

    # Se o envio falhou, cancela a pendência. Em caso de sucesso, a pendência
    # é encerrada depois, pela telemetria ou pelo timeout.
    def _calibracao_enviada(self, sucesso):
        if not sucesso:
            self._calibracao_pendente = False
            self.tab_func.definir_calibracao_pendente(False)

    # ---- Câmera e janelas secundárias ----

    # Abre a janela da câmera usando a URL configurada.
    def abrir_camera(self):
        abrir_janela_camera(self.window, CAMERA_URL)

    # Abre a janela de gráficos, ou traz para frente se já estiver aberta.
    def abrir_graficos(self):
        if self._janela_graficos is not None and self._janela_graficos.winfo_exists():
            self._janela_graficos.lift()
            self._janela_graficos.focus()
            return
        self._janela_graficos = JanelaGraficos(self.window, self.esp, self)
        self._atualizar_modo_grafico()

    # Abre a janela de calibração PID, ou traz para frente se já estiver aberta.
    def abrir_janela_calibracao(self):
        if (self._janela_calibracao_pid is not None and
                self._janela_calibracao_pid.winfo_exists()):
            self._janela_calibracao_pid.lift()
            self._janela_calibracao_pid.focus()
            return
        self._janela_calibracao_pid = JanelaCalibracao(self.window, self)

    # Aplica uma nova configuração do modo PID. Só é aceita fora do voo e,
    # se estiver conectado, só é salva depois que o ESP32 recebe o comando.
    # Retorna True se a configuração foi aplicada.
    def configurar_modo_pid(self, calibracao, eixo, altitude):
        if self._estado_voo == 2:                           # 2 = em voo: não permite alterar
            self._atualizar_estado_janela_calibracao(self.ativo, self._estado_voo)
            return False

        if eixo not in ("X", "Y", "Z", "ALT"):
            return False
        novo_modo = bool(calibracao)
        nova_altitude = bool(altitude)
        # Com a conexão ativa, envia primeiro ao ESP32; se falhar, mantém a configuração antiga
        if self.ativo and not self.esp.enviar_modo_pid(
                novo_modo, eixo, nova_altitude):
            return False

        self.modo_calibracao_pid = novo_modo
        self.eixo_calibracao_pid = eixo
        self.altitude_pid_ativa = nova_altitude
        self._atualizar_modo_grafico()
        self._atualizar_estado_janela_calibracao(self.ativo, self._estado_voo)
        return True

    # Atualiza a janela de calibração PID, se ela estiver aberta.
    def _atualizar_estado_janela_calibracao(self, conectado, estado_voo):
        if (self._janela_calibracao_pid is not None and
                self._janela_calibracao_pid.winfo_exists()):
            self._janela_calibracao_pid.atualizar_estado(conectado, estado_voo)

    # Envia a configuração PID atual para a janela de gráficos, se ela estiver aberta.
    def _atualizar_modo_grafico(self):
        if self._janela_graficos is not None and self._janela_graficos.winfo_exists():
            self._janela_graficos.atualizar_modo(
                self.modo_calibracao_pid, self.eixo_calibracao_pid,
                self.altitude_pid_ativa,
            )

    # ---- Controle físico (thread de envio) ----

    # Lê o controle físico e envia os setpoints ao ESP32, no máximo a cada 20 ms (50 vezes por segundo).
    def _loop_controle(self):
        ultimo_envio = 0.0
        ultimo_diagnostico = 0.0 # controla a frequência das mensagens de log
        while self.ativo:
            cmd = self.controle.ler_comandos()
            if cmd is None:
                # Sem amostra válida: avisa a cada 2 s e espera um pouco antes de tentar de novo
                agora = time.monotonic()
                if agora - ultimo_diagnostico >= 2.0:
                    print("Controle ativo, mas sem amostra XInput válida; nenhum setpoint foi enviado.")
                    ultimo_diagnostico = agora
                time.sleep(0.01)
                continue

            # Respeita o intervalo mínimo de 20 ms entre envios
            agora = time.monotonic()
            if agora - ultimo_envio < 0.02:
                continue

            roll, pitch, yaw, throttle = cmd
            if self.esp.enviar_setpoint(roll, pitch, yaw, throttle):
                ultimo_envio = agora
                # Log de diagnóstico no máximo uma vez por segundo
                if agora - ultimo_diagnostico >= 1.0:
                    print(f"Setpoint enviado ao ESP32: roll={roll:.1f} pitch={pitch:.1f} yaw={yaw:.1f} throttle={throttle:.3f}")
                    ultimo_diagnostico = agora
            else:
                time.sleep(0.01)

    # ---- Telemetria (thread de recepção) ----

    # Recebe as linhas de telemetria do ESP32, valida e coloca na fila para a interface.
    def _loop_receptor(self):
        while self.ativo:
            dados = self.esp.receber_dados()
            if dados:
                msg, valores = processar_dados_esp(dados)
                if valores is not None:
                    self._ultima_telemetria = time.monotonic()
                    self._telemetria_limpa = False
                    try:
                        self._fila_telemetria.put_nowait((valores, time.monotonic()))
                    except queue.Full:
                        # Fila cheia: descarta o item mais antigo e tenta colocar o novo
                        try:
                            self._fila_telemetria.get_nowait()
                        except queue.Empty:
                            pass
                        try:
                            self._fila_telemetria.put_nowait((valores, time.monotonic()))
                        except queue.Full:
                            pass
                else:
                    print(f"ESP32: {msg}")
                # Continua lendo sem dormir: linhas já acumuladas no mesmo recv() são
                # consumidas logo, sem limitar a recepção à taxa de envio do ESP32.
                continue
            time.sleep(0.005)

    # ---- Interface (thread principal, a cada 50 ms) ----

    # Retira da fila todos os frames pendentes, atualiza a interface com o mais recente,
    # envia as amostras válidas ao gráfico e marca a telemetria como desatualizada se ela parar.
    def _processar_fila_telemetria(self):
        if not self.window.winfo_exists():
            return

        dados = None # último frame retirado da fila
        amostras_grafico = [] # frames válidos para o gráfico
        while True:
            try:
                valores, instante = self._fila_telemetria.get_nowait()
                dados = valores
                self._estado_voo = valores["estado_voo"]
                # Só entram no gráfico frames com link e sistema prontos
                if valores["link_ok"] and valores["sistema_pronto"]:
                    amostras_grafico.append((valores, instante))
            except queue.Empty:
                break

        if dados is not None:
            self.tab_func.painel.atualizar(dados)
            self._ultimo_status_mag = dados["mag_status"]
            # Magnetômetro indisponível nos status 4 e 5
            self.tab_func.atualizar_estado(
                self.ativo,
                magnetometro_disponivel=dados["mag_status"] not in (4, 5),
                estado_voo=self._estado_voo,
            )
            self._atualizar_estado_janela_calibracao(self.ativo, self._estado_voo)
            # Encerra a pendência quando: o ESP32 entra em calibração (status 1), ou
            # reporta um status novo de erro/conclusão (3, 4, 5), ou passaram 3 s sem resposta
            if self._calibracao_pendente and (
                    dados["mag_status"] == 1 or
                    (dados["mag_status"] in (3, 4, 5) and dados["mag_status"] != self._status_mag_no_pedido) or
                    time.monotonic() - self._tempo_pedido_calibracao > 3.0):
                self._calibracao_pendente = False
            self.tab_func.definir_calibracao_pendente(
                self._calibracao_pendente or dados["mag_status"] == 1,
                calibrando=dados["mag_status"] == 1,
            )

        # Envia todas as amostras válidas ao gráfico, não só a última
        if (self._janela_graficos is not None and self._janela_graficos.winfo_exists()):
            for valores, instante in amostras_grafico:
                self._janela_graficos.adicionar_dado(valores, instante)

        # Sem telemetria por mais de 2 s: marca o painel como desatualizado (uma vez só)
        if (not self._telemetria_limpa and self._ultima_telemetria
                and time.monotonic() - self._ultima_telemetria > 2.0):
            self.tab_func.painel.limpar("TELEMETRIA DESATUALIZADA")
            self._telemetria_limpa = True

        self.window.after(50, self._processar_fila_telemetria)

    # Atualiza os botões conforme a conexão e o estado de voo atuais.
    def _atualizar_botoes(self, conectado):
        self.tab_func.atualizar_estado(conectado, estado_voo=self._estado_voo)

    # Inicia o loop principal da interface (bloqueia até a janela fechar).
    def run(self):
        self.window.mainloop()