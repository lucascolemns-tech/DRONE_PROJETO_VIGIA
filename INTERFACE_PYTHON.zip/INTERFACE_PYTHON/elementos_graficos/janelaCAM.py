import os

import customtkinter as ctk
from nucleo import Camera
from config import ICONE_IMG


# Abre uma janela Toplevel que mostra o vídeo da câmera em tempo quase real.
# A captura roda em thread separada (classe Camera); esta função só cuida da interface.
def abrir_janela_camera(parent, url):
    cam = Camera(url)
    if not cam.iniciar(): # iniciar() devolve True se a thread foi criada
        print(f"ERRO: não foi possível abrir câmera em {url}")
        return

    janela = ctk.CTkToplevel(parent) # janela secundária ligada à janela principal
    janela.title("Câmera")
    janela.geometry("640x480")
    janela.configure(fg_color="#EEF0F3")
    # Aplica o ícone da aplicação, se o arquivo existir (falha silenciosa)
    if os.path.isfile(ICONE_IMG):
        try:
            janela.iconbitmap(ICONE_IMG)
        except Exception:
            pass

    # Painel branco arredondado que contém o vídeo
    painel = ctk.CTkFrame(
        janela, fg_color="#FFFFFF", corner_radius=16,
        border_width=1, border_color="#D1D5DB",
    )
    painel.pack(fill="both", expand=True, padx=12, pady=12)
    # Label que exibe os frames; começa vazio até o primeiro frame chegar
    label = ctk.CTkLabel(painel, text="", corner_radius=12)
    label.pack(fill="both", expand=True, padx=8, pady=8)
    # Flag compartilhada com as funções internas: indica se a janela ainda está ativa
    estado = {"ativa": True}

    # Atualiza a imagem na tela e agenda a próxima atualização (a cada 30 ms).
    def atualizar():
        if not estado["ativa"]:
            return
        # Usa o tamanho atual da janela; se ainda não tiver tamanho, assume 640x480
        w = janela.winfo_width() or 640
        h = janela.winfo_height() or 480
        img = cam.ler_frame(w, h)
        if img is not None:
            label.configure(image=img, text="")
            # Guarda a referência no label: sem ela o Tkinter descarta a imagem e ela some
            setattr(label, "image", img)
        else:
            # Ainda sem frame: mostra o erro da câmera, se houver, ou a mensagem de conexão
            label.configure(text=cam.erro() or "Conectando à câmera...")
        if estado["ativa"]:
            janela.after(30, atualizar)

    # Fecha a câmera e a janela ao clicar no X
    def fechar():
        estado["ativa"] = False # impede novos agendamentos de atualizar()
        cam.fechar() # para a thread de captura
        janela.destroy()

    janela.protocol("WM_DELETE_WINDOW", fechar)
    atualizar() # inicia o ciclo de atualização