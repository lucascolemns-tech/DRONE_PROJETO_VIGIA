import os

import customtkinter as ctk

from config import ICONE_IMG


# Eixos que podem ser escolhidos para calibração PID.
EIXOS_PID = ("X", "Y", "Z", "ALT")


# Janela secundária para configurar o modo PID: ativar calibração, escolher o eixo
# e decidir se a altitude fica ativa durante a operação.
class JanelaCalibracao(ctk.CTkToplevel):
    def __init__(self, master, app):
        super().__init__(master)
        self.app = app # aplicação principal (fornece estado e configurar_modo_pid)
        self.title("Calibração PID")
        self.geometry("440x210")
        self.resizable(False, False)
        self.transient(master) # mantém a janela sobre a janela principal
        self.configure(fg_color="#EEF0F3")
        # Aplica o ícone da aplicação, se o arquivo existir (falha silenciosa)
        if os.path.isfile(ICONE_IMG):
            try:
                self.iconbitmap(ICONE_IMG)
            except Exception:
                pass

        # Painel branco arredondado que contém os controles
        painel = ctk.CTkFrame(
            self, fg_color="#FFFFFF", corner_radius=16,
            border_width=1, border_color="#D1D5DB",
        )
        painel.pack(fill="both", expand=True, padx=10, pady=10)

        # Chave que liga e desliga o modo de calibração, com o estado atual da aplicação
        self.var_calibracao = ctk.BooleanVar(value=app.modo_calibracao_pid)
        self.switch_calibracao = ctk.CTkSwitch(
            painel,
            text="Calibração PID",
            variable=self.var_calibracao,
            command=self._alterar_configuracao,
        )
        self.switch_calibracao.pack(anchor="w", padx=20, pady=(18, 12))

        # Linha com um botão de rádio para cada eixo (X, Y, Z, ALT)
        self.var_eixo = ctk.StringVar(value=app.eixo_calibracao_pid)
        faixa_eixos = ctk.CTkFrame(painel, fg_color="transparent")
        faixa_eixos.pack(fill="x", padx=20, pady=(0, 12))
        self.opcoes_eixo = []
        for eixo in EIXOS_PID:
            opcao = ctk.CTkRadioButton(
                faixa_eixos,
                text=eixo,
                variable=self.var_eixo,
                value=eixo,
                command=self._alterar_configuracao,
            )
            opcao.pack(side="left", expand=True, padx=4)
            self.opcoes_eixo.append(opcao)

        # Chave que define se a altitude fica ativa durante a operação
        self.var_altitude = ctk.BooleanVar(value=app.altitude_pid_ativa)
        self.switch_altitude = ctk.CTkSwitch(
            painel,
            text="Altitude na operação",
            variable=self.var_altitude,
            command=self._alterar_configuracao,
        )
        self.switch_altitude.pack(anchor="w", padx=20, pady=(0, 14))
        self.atualizar_estado(app.ativo, app._estado_voo)

    # Envia a configuração atual dos controles para a aplicação.
    # Se a aplicação recusar, devolve os controles aos valores que ela tem de fato.
    def _alterar_configuracao(self):
        sucesso = self.app.configurar_modo_pid(
            calibracao=self.var_calibracao.get(),
            eixo=self.var_eixo.get(),
            altitude=self.var_altitude.get(),
        )
        if not sucesso:
            self.var_calibracao.set(self.app.modo_calibracao_pid)
            self.var_eixo.set(self.app.eixo_calibracao_pid)
            self.var_altitude.set(self.app.altitude_pid_ativa)
        self._atualizar_habilitacao()

    # Habilita ou desabilita os controles conforme o drone está voando e se
    # o modo de calibração está ligado. Durante o voo, nada pode ser alterado.
    def _atualizar_habilitacao(self):
        voando = self.app._estado_voo == 2   # estado 2 = em voo
        self.switch_calibracao.configure(state="disabled" if voando else "normal")
        self.switch_altitude.configure(state="disabled" if voando else "normal")
        # Os eixos só ficam disponíveis com a calibração ligada e fora do voo
        estado_eixos = (
            "normal"
            if self.var_calibracao.get() and not voando
            else "disabled"
        )
        for opcao in self.opcoes_eixo:
            opcao.configure(state=estado_eixos)

    # Chamado pela aplicação quando a conexão ou o estado de voo muda.
    # Atualiza a habilitação dos controles. Os parâmetros são recebidos mas não usados aqui.
    def atualizar_estado(self, conectado, estado_voo):
        self._atualizar_habilitacao()