import customtkinter as ctk
from ..tema import estilo_botao
from ..painel_telemetria import PainelTelemetria


# Aba de operação: coluna esquerda com os botões de controle e coluna direita com o painel de telemetria.
# Cada botão tem um estado "habilitado" próprio, que decide se o clique tem efeito e como ele aparece.
class TabOperacao(ctk.CTkFrame):
    def __init__(self, master, app):
        super().__init__(master, fg_color="transparent")
        self.app = app  # aplicação principal, que recebe as ações dos botões

        # Guarda o estado de cada botão que pode ser ligado/desligado
        self._habilitados = {
            "conectar":  True,     # começa ativo
            "manual":    False,
            "teste":     False,
            "calibrar":  False,
            "finalizar": False,
            "camera":    True,
            "graficos":  False,
        }

        # Coluna esquerda: botões.
        # width/height + pack_propagate(False) fazem a moldura manter o mesmo tamanho
        # do painel PID, independente de quantos botões tem dentro.
        esq = ctk.CTkFrame(self, corner_radius=8, fg_color="#FFFFFF",
                            border_width=3, border_color="#979DA2",
                            width=200, height=650)
        esq.pack(fill="both", expand=True, padx=15, pady=15, side="left")
        esq.pack_propagate(False)

        # Coluna direita: console de telemetria
        dir_ = ctk.CTkFrame(self, width=550, height=650, corner_radius=8, fg_color="#FFFFFF",
                            border_width=3, border_color="#979DA2")
        dir_.pack(fill="both", expand=True, padx=15, pady=15, side="right")

        self.painel = PainelTelemetria(dir_)
        self.painel.pack(fill="both", expand=True)

        e = estilo_botao()
        # **e não gera erro no IntelliSense, mas funciona: passa para o botão os atributos de estilo
        self.btn_conectar = ctk.CTkButton(esq, text="estabelecer comm", command=self._clicou_conectar, **e)
        self.btn_manual = ctk.CTkButton(esq, text="controle manual", command=self._clicou_manual, **e)
        self.btn_teste = ctk.CTkButton(esq, text="teste motores", command=self._clicou_teste, **e)
        # Manual e teste ainda não têm função, então começam desabilitados
        self.btn_manual.configure(state="disabled")
        self.btn_teste.configure(state="disabled")
        self.btn_calibrar = ctk.CTkButton(esq, text="calibrar bússola",
                                           command=self._clicou_calibrar, **e)
        self.btn_calibrar.configure(state="disabled")
        self.btn_finalizar = ctk.CTkButton(esq, text="finalizar comm", command=self._clicou_finalizar, **e)
        # Este botão abre a janela de calibração PID direto na aplicação
        self.btn_calibracao_pid = ctk.CTkButton(
            esq, text="calibração PID", command=app.abrir_janela_calibracao, **e,
        )
        self.btn_camera = ctk.CTkButton(esq, text="abrir câmera", command=self._clicou_camera, **e)
        self.btn_camera.configure(state="disabled")
        self.btn_graficos = ctk.CTkButton(esq, text="def gráficos", command=app.abrir_graficos, **e)
        self.btn_graficos.configure(state="disabled")

        # Empilha os botões verticalmente, ocupando a largura da coluna
        for b in (self.btn_conectar, self.btn_manual, self.btn_teste, self.btn_calibrar,
                  self.btn_calibracao_pid,
                  self.btn_finalizar, self.btn_camera, self.btn_graficos):
            b.pack(fill="x")

        self._atualizar_aparencia()

    # Funções dos botões: só agem se o botão estiver habilitado no controle interno.

    # Inicia a comunicação com o ESP32
    def _clicou_conectar(self):
        if self._habilitados["conectar"]:
            self.app.iniciar_comunicacao()

    # Placeholder: controle manual ainda não implementado
    def _clicou_manual(self):
        if self._habilitados["manual"]:
            pass   # sem função no original

    # Placeholder: teste de motores ainda não implementado
    def _clicou_teste(self):
        if self._habilitados["teste"]:
            pass   # sem função no original

    # Inicia a calibração do magnetômetro
    def _clicou_calibrar(self):
        if self._habilitados["calibrar"]:
            self.app.iniciar_calibracao_magnetometro()

    # Encerra a comunicação com o ESP32
    def _clicou_finalizar(self):
        if self._habilitados["finalizar"]:
            self.app.finalizar_comunicacao()

    # Abre a janela da câmera
    def _clicou_camera(self):
        if self._habilitados["camera"]:
            self.app.abrir_camera()

    # Ajusta a cor do texto e a cor de hover de cada botão conforme ele está habilitado.
    # Botões desabilitados ficam com texto cinza e hover sem destaque.
    def _atualizar_aparencia(self):
        mapa = {
            "conectar":  self.btn_conectar,
            "manual":    self.btn_manual,
            "teste":     self.btn_teste,
            "calibrar":  self.btn_calibrar,
            "finalizar": self.btn_finalizar,
            "camera":    self.btn_camera,
            "graficos":  self.btn_graficos,
        }

        for chave, botao in mapa.items():
            if self._habilitados[chave]:
                botao.configure(text_color="#000000",
                                hover_color="#D1D5DB")
            else:
                botao.configure(text_color="#9CA3AF",
                                hover_color="#FFFFFF")

    # Recalcula quais botões ficam habilitados a partir do estado da conexão,
    # do magnetômetro e do estado de voo. Chamado sempre que esse estado muda.
    def atualizar_estado(self, conectado: bool, magnetometro_disponivel: bool = True,
                         estado_voo: int = 0):
        self._habilitados["conectar"]  = not conectado        # só conecta se não estiver conectado
        self._habilitados["manual"]    = False
        self._habilitados["teste"]     = False
        # Calibrar exige conexão, magnetômetro disponível e drone fora de voo (2 = em voo)
        self._habilitados["calibrar"]  = (
            conectado and magnetometro_disponivel and estado_voo != 2
        )
        self._habilitados["finalizar"] = conectado
        self._habilitados["graficos"]  = conectado
        self.btn_calibrar.configure(state="normal" if self._habilitados["calibrar"] else "disabled")
        self.btn_graficos.configure(state="normal" if self._habilitados["graficos"] else "disabled")
        self._atualizar_aparencia()

    # Mostra o estado de pendência da calibração no botão do magnetômetro.
    # "iniciando..." enquanto aguarda o ESP32 e "calibrando..." depois que ele começou.
    def definir_calibracao_pendente(self, pendente, calibrando=False):
        self.btn_calibrar.configure(
            text=("calibrando..." if calibrando else "iniciando...")
            if pendente else "calibrar bússola",
        )
        # Durante a pendência, o botão fica desabilitado para evitar cliques repetidos
        self.btn_calibrar.configure(state="disabled" if pendente or not self._habilitados["calibrar"] else "normal")