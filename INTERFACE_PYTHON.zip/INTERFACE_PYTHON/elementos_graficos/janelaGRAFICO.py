import tkinter as tk
import csv
import math
import os
import time

import customtkinter as ctk
import numpy as np
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

from config import KP_PADRAO, KI_PADRAO, KD_PADRAO, PASTA_LOGS, ICONE_IMG
from .tema import (
    COR_BORDA, COR_BOTAO_HOVER, COR_FUNDO, COR_TEXTO, FONTE_LABEL,
    FONTE_ROTULO, FONTE_TITULO, estilo_botao,
)


# Gera a curva de referência (a "onda" que o drone deve seguir) para os instantes xs.
#  - tipo: "Senoidal", "Quadrada", "Triangular" ou qualquer outro (vira constante).
#  - amplitude, periodo: forma da onda; offset: deslocamento vertical.
#  - origem: instante em que a referência começou, para a onda recomeçar do zero.
def gerar_referencia(xs, tipo, amplitude, periodo, offset, origem=0.0):
    xs = np.asarray(xs, dtype=float)
    # Fase em radianos, medida a partir do início da referência
    fase = 2 * np.pi * (xs - origem) / periodo
    if tipo == "Senoidal":
        onda = np.sin(fase)
    elif tipo == "Quadrada":
        onda = np.where(np.sin(fase) >= 0, 1.0, -1.0)
    elif tipo == "Triangular":
        # arcsin(sin) gera uma onda triangular entre -1 e 1
        onda = (2.0 / np.pi) * np.arcsin(np.sin(fase))
    else:
        onda = np.zeros_like(xs) # Constante: sem variação, só o offset
    return offset + amplitude * onda


# Janela de análise PID: mostra o gráfico da resposta do drone (ângulos e altitude) junto
# com a referência, permite ajustar os ganhos e a referência de teste, e salvar os dados em CSV.
class JanelaGraficos(ctk.CTkToplevel):
    def __init__(self, parent, esp, app):
        super().__init__(parent)
        self.title("Análise PID")
        if os.path.isfile(ICONE_IMG):
            try:
                self.iconbitmap(ICONE_IMG)
            except Exception:
                pass
        self.configure(fg_color="#EEF0F3")
        self.geometry("1200x700")
        self.esp = esp # cliente TCP para enviar comandos
        self.app = app # aplicação principal (estado de voo, modo PID)
        self.modo_calibracao = app.modo_calibracao_pid  # calibração ligada?
        self.eixo_pid = app.eixo_calibracao_pid # eixo em calibração
        self.altitude_pid_ativa = app.altitude_pid_ativa

        # Buffers do gráfico: tempos (xs) e amostras correspondentes
        self.xs = []
        self.amostras = []
        self.tamanho = 200 # máximo de amostras mantidas
        self._plot_dirty = True # True quando o gráfico precisa ser redesenhado
        self.inicio = time.monotonic() # referência de tempo do gráfico
        self.inicio_referencia = 0.0 # instante em que a referência atual começou

        # Parâmetros da referência de teste
        self.amplitude = 15
        self.xbase = 0 # offset
        self.periodo = 15
        self.resposta = "Constante"                     

        # Campos da interface (valores em texto)
        self.var_kp = tk.StringVar(value=KP_PADRAO)
        self.var_ki = tk.StringVar(value=KI_PADRAO)
        self.var_kd = tk.StringVar(value=KD_PADRAO)
        # Altitude usa amplitude pequena (em metros); os ângulos usam graus
        padrao_referencia = (
            "0.5,15,0"
            if self.modo_calibracao and self.eixo_pid == "ALT"
            else "20,15,0"
        )
        self.var_onda = tk.StringVar(value=padrao_referencia)
        self.var_tipo = tk.StringVar(value="Constante")

        self._construir_interface()
        self._loop_desenho()

    # Monta os dois lados da janela: controles à esquerda e gráfico à direita.
    def _construir_interface(self):
        # Coluna esquerda: controles
        ctrl = ctk.CTkFrame(self, fg_color="#FFFFFF",
                            corner_radius=8, border_width=3,
                            border_color=COR_BORDA, width=300, height=650)
        ctrl.pack(side="left", fill="y", padx=15, pady=15)
        ctrl.pack_propagate(False)                      # mantém o tamanho fixo

        # Área rolável, para caber todos os controles em telas menores
        controles = ctk.CTkScrollableFrame(
            ctrl, fg_color="transparent", corner_radius=10,
            scrollbar_button_color="#D1D5DB",
            scrollbar_button_hover_color="#9CA3AF",
        )
        controles.pack(fill="both", expand=True, padx=10, pady=(10, 4))

        ctk.CTkLabel(
            controles, text="Análise PID",
            font=FONTE_TITULO, text_color="#111827",
        ).pack(anchor="w", pady=(4, 2))
        ctk.CTkLabel(
            controles, text="Ajuste os ganhos e acompanhe o canal PID selecionado.",
            font=("Arial", 11), text_color="#6B7280",
            wraplength=245, justify="left",
        ).pack(anchor="w", pady=(0, 12))

        # Bloco dos ganhos KP, KI e KD
        ctk.CTkLabel(
            controles, text="GANHOS PID",
            font=FONTE_ROTULO, text_color="#374151",
        ).pack(anchor="w", pady=(2, 3))

        for rotulo, var in (("KP", self.var_kp),
                            ("KI", self.var_ki),
                            ("KD", self.var_kd)):
            ctk.CTkLabel(
                controles, text=rotulo,
                font=FONTE_ROTULO, text_color="#4B5563",
            ).pack(anchor="w", pady=(7, 3))
            ctk.CTkEntry(
                controles, textvariable=var, height=36,
                fg_color=COR_FUNDO, text_color=COR_TEXTO,
                border_width=2, border_color=COR_BORDA,
                corner_radius=6, font=FONTE_LABEL,
            ).pack(fill="x")

        estilo = estilo_botao()
        # Mantém o estilo branco/preto da janela principal, com botões um pouco maiores
        estilo.update(height=42, font=("Arial Black", 13))
        ctk.CTkButton(
            controles, text="Enviar ganhos PID",
            command=self._enviar_pid, **estilo,
        ).pack(fill="x", pady=(12, 16))

        # Bloco da referência de teste: tipo, parâmetros e botões de envio
        ctk.CTkLabel(
            controles, text="REFERÊNCIA DE TESTE",
            font=FONTE_ROTULO, text_color="#374151",
        ).pack(anchor="w", pady=(0, 7))

        ctk.CTkOptionMenu(
            controles,
            variable=self.var_tipo,
            values=["Constante", "Senoidal", "Quadrada", "Triangular"],
            height=36,
            fg_color=COR_FUNDO,
            button_color=COR_FUNDO,
            button_hover_color=COR_BOTAO_HOVER,
            text_color=COR_TEXTO,
            font=FONTE_LABEL,
            dropdown_fg_color=COR_FUNDO,
            dropdown_text_color=COR_TEXTO,
            dropdown_hover_color=COR_BOTAO_HOVER,
        ).pack(fill="x", pady=(0, 9))

        ctk.CTkLabel(
            controles,
            text="Amplitude, período (s), offset\nExemplo: 20,15,0",
            font=("Arial", 11), text_color="#6B7280",
            justify="left",
        ).pack(anchor="w", pady=(0, 5))
        ctk.CTkEntry(
            controles, textvariable=self.var_onda, height=36,
            fg_color=COR_FUNDO, text_color=COR_TEXTO,
            border_width=2, border_color=COR_BORDA,
            corner_radius=6, font=FONTE_LABEL,
        ).pack(fill="x")

        ctk.CTkButton(
            controles, text="Atualizar referência",
            command=self._atualizar_referencia, **estilo,
        ).pack(fill="x", pady=(10, 5))

        ctk.CTkButton(
            controles, text="Enviar referência ao drone",
            command=self._enviar_referencia_drone, **estilo,
        ).pack(fill="x", pady=5)

        ctk.CTkButton(
            controles, text="Parar referência no drone",
            command=self._parar_referencia_drone, **estilo,
        ).pack(fill="x", pady=5)

        ctk.CTkButton(
            controles, text="Salvar gráfico",
            command=self._salvar_grafico, **estilo,
        ).pack(fill="x", pady=(5, 10))

        # Linha de status na parte de baixo da coluna, fora da área rolável
        self.lbl_status = ctk.CTkLabel(
            ctrl, text="Aguardando telemetria",
            font=("Arial", 11), text_color="#4B5563",
            fg_color="#F3F4F6", corner_radius=6,
            wraplength=250, justify="left", anchor="w",
            height=42,
        )
        self.lbl_status.pack(fill="x", padx=12, pady=(4, 12))

        # Coluna direita: título, gráfico Matplotlib e barra de ferramentas
        fr_graf = ctk.CTkFrame(
            self, fg_color=COR_FUNDO, corner_radius=8,
            border_width=3, border_color=COR_BORDA,
        )
        fr_graf.pack(side="left", fill="both", expand=True,
                     padx=(0, 15), pady=15)

        self.lbl_titulo_grafico = ctk.CTkLabel(
            fr_graf, text="Acompanhamento do roll",
            font=("Arial Black", 15), text_color="#111827",
        )
        self.lbl_titulo_grafico.pack(anchor="w", padx=18, pady=(14, 0))

        # Figura Matplotlib com o eixo principal (ângulos) e um eixo secundário (altitude)
        self.fig = Figure(figsize=(9, 6), dpi=85, facecolor="#FFFFFF")
        self.ax = self.fig.add_subplot(111)
        self.ax.set_facecolor("#FFFFFF")
        self.ax.set_title("Roll medido x referência",
                          fontsize=12, color="#111827", pad=12)
        self.ax.set_xlabel("Tempo (s)", fontsize=10, color="#374151")
        self.ax.set_ylabel("Ângulo (°)", fontsize=10, color="#374151")
        self.ax.tick_params(colors="#4B5563", labelsize=9)
        self.ax.grid(True, color="#E5E7EB", linewidth=0.8)
        self.ax.set_axisbelow(True) # grade fica atrás das linhas
        for borda in self.ax.spines.values():
            borda.set_color("#D1D5DB")

        # Eixo secundário para a altitude, com escala própria
        self.ax_alt = self.ax.twinx()
        self.ax_alt.set_visible(False)
        self.ax_alt.tick_params(colors="#4B5563", labelsize=9)
        self.ax_alt.set_ylabel("Altitude (m)", fontsize=10, color="#374151")

        # Uma linha para cada canal medido. "alt_secondary" é a altitude no eixo da direita.
        self.linhas = {
            "ang_x": self.ax.plot([], [], color="#2563EB", linewidth=1.8,
                                  label="Roll medido")[0],
            "ang_y": self.ax.plot([], [], color="#16A34A", linewidth=1.8,
                                  label="Pitch medido")[0],
            "ang_z": self.ax.plot([], [], color="#7C3AED", linewidth=1.8,
                                  label="Yaw medido")[0],
            "alt": self.ax.plot([], [], color="#F97316", linewidth=1.8,
                                label="Altitude medida")[0],
            "alt_secondary": self.ax_alt.plot(
                [], [], color="#F97316", linewidth=1.8,
                label="Altitude medida",
            )[0],
        }
        # Linha vermelha da referência
        self.linha_sp, = self.ax.plot(
            [], [], color="#EF4444", linewidth=1.8,
            label="Referência",
        )
        self._atualizar_modo_plot()

        # Gráfico embutido no Tkinter
        self.canvas = FigureCanvasTkAgg(self.fig, master=fr_graf)
        self.canvas.get_tk_widget().pack(
            fill="both", expand=True, padx=14, pady=(4, 0),
        )

        # Barra do Matplotlib (zoom, pan, salvar imagem)
        barra_grafico = ctk.CTkFrame(
            fr_graf, fg_color="#F3F4F6", corner_radius=6, height=38,
        )
        barra_grafico.pack(fill="x", padx=14, pady=10)
        toolbar = NavigationToolbar2Tk(
            self.canvas, barra_grafico, pack_toolbar=False,
        )
        toolbar.update()
        toolbar.pack(side="left", padx=4, pady=2)

    # ---- Ações dos botões ----

    # Envia os ganhos PID ao ESP32. Bloqueado durante o voo.
    # Na calibração, envia só para o eixo escolhido; fora dela, para todos.
    def _enviar_pid(self):
        if self.app._estado_voo == 2:                   # 2 = em voo
            self.lbl_status.configure(text="Ganhos PID bloqueados enquanto o drone está voando")
            return
        alvo = self.eixo_pid if self.modo_calibracao else "ALL"
        if self.esp.enviar_pid(
                self.var_kp.get(), self.var_ki.get(), self.var_kd.get(), alvo):
            self.lbl_status.configure(text=f"Ganhos enviados para {alvo}; aceitos só desarmado")
        else:
            self.lbl_status.configure(text="Falha ao enviar ganhos PID")

    # Lê os campos de referência, valida e atualiza o gráfico.
    # Retorna True se os parâmetros forem válidos.
    def _atualizar_referencia(self):
        self.resposta = self.var_tipo.get()
        try:
            # Formato esperado: "amplitude,período,offset"
            a, p, x = (float(valor) for valor in self.var_onda.get().split(","))
            if not all(math.isfinite(valor) for valor in (a, p, x)) or p < 0.5:
                raise ValueError
            # Altitude aceita até 10; os ângulos, até 45 (amplitude + offset)
            limite = 10.0 if self._alvo_referencia() == "ALT" else 45.0
            if abs(a) + abs(x) > limite:
                raise ValueError
            self.amplitude, self.periodo, self.xbase = a, p, x
            # A referência recomeça a partir da última amostra
            self.inicio_referencia = self.xs[-1] if self.xs else 0.0
            self._plot_dirty = True
        except (TypeError, ValueError, OverflowError):
            self.lbl_status.configure(text="Parâmetros inválidos")
            return False
        self.lbl_status.configure(text=f"Referência simulada: {self.resposta}")
        return True

    # Valida a referência localmente e a envia ao drone.
    def _enviar_referencia_drone(self):
        if not self._atualizar_referencia():
            return
        alvo = self._alvo_referencia()
        if self.esp.enviar_referencia(
                self.resposta, self.amplitude, self.periodo, self.xbase, alvo):
            self.inicio_referencia = self.xs[-1] if self.xs else 0.0
            self.lbl_status.configure(text=f"Referência {alvo} enviada; use o controle de throttle")
        else:
            self.lbl_status.configure(text="Referência fora da faixa ou sem conexão")

    # Pede ao ESP32 que desligue a referência ativa.
    def _parar_referencia_drone(self):
        if self.esp.desativar_referencia():
            self.lbl_status.configure(text="Referência desativada no drone")
        else:
            self.lbl_status.configure(text="Falha ao desativar a referência")

    # Acrescenta as amostras atuais, com a referência correspondente, ao CSV de calibração.
    # O cabeçalho só é gravado quando o arquivo está vazio.
    def _salvar_grafico(self):
        try:
            if not self.xs:
                self.lbl_status.configure(text="Sem amostras para salvar")
                return
            caminho = os.path.join(PASTA_LOGS, "pid_calibracao.csv")
            with open(caminho, "a", newline="", encoding="utf-8") as arquivo:
                gravador = csv.writer(arquivo)
                if arquivo.tell() == 0: # arquivo novo: grava o cabeçalho
                    gravador.writerow(("tempo_s", "roll_graus", "pitch_graus", "yaw_graus",
                                       "altitude_m", "referencia"))
                referencia = gerar_referencia(
                    self.xs, self.resposta, self.amplitude, self.periodo,
                    self.xbase, self.inicio_referencia,
                )
                # Uma linha por amostra: tempo, medições e referência no mesmo instante
                gravador.writerows(
                    (tempo, amostra["ang_x"], amostra["ang_y"], amostra["ang_z"],
                     amostra["alt"], ref)
                    for tempo, amostra, ref in zip(self.xs, self.amostras, referencia)
                )
            self.lbl_status.configure(text="Dados salvos em logs/pid_calibracao.csv")
        except Exception as e:
            self.lbl_status.configure(text=f"Erro ao salvar: {e}")

    # ---- Recebimento de dados ----

    # Chamado pela aplicação a cada pacote do ESP32. Guarda a amostra e
    # descarta as mais antigas quando o limite de tamanho é ultrapassado.
    def adicionar_dado(self, dados, instante=None):
        if isinstance(dados, dict):
            amostra = {
                chave: float(dados.get(chave, 0.0))
                for chave in ("ang_x", "ang_y", "ang_z", "alt")
            }
        else:
            # Aceita também um número solto, tratado como roll
            amostra = {"ang_x": float(dados), "ang_y": 0.0, "ang_z": 0.0, "alt": 0.0}
        if not all(math.isfinite(valor) for valor in amostra.values()):
            return
        instante = time.monotonic() if instante is None else instante
        tempo = instante - self.inicio                 
        if tempo < 0:
            return
        self.xs.append(tempo)
        self.amostras.append(amostra)
        if len(self.amostras) > self.tamanho:
            self.xs.pop(0)
            self.amostras.pop(0)
        self._plot_dirty = True                         

    # Recebe o modo PID atual da aplicação e reconfigura o gráfico.
    def atualizar_modo(self, modo_calibracao, eixo_pid, altitude_ativa):
        eixo_anterior = self._alvo_referencia()
        self.modo_calibracao = bool(modo_calibracao)
        self.eixo_pid = eixo_pid
        self.altitude_pid_ativa = bool(altitude_ativa)
        # Ao passar para altitude, troca a referência padrão de 20 para 0,5 m
        if self._alvo_referencia() == "ALT" and eixo_anterior != "ALT" and self.var_onda.get() == "20,15,0":
            self.var_onda.set("0.5,15,0")
        self._atualizar_modo_plot()

    # Eixo que receberá a referência: o eixo em calibração, ou X na operação.
    def _alvo_referencia(self):
        return self.eixo_pid if self.modo_calibracao else "X"

    # Decide quais linhas aparecem e atualiza título, rótulos e legenda conforme o modo.
    def _atualizar_modo_plot(self):
        if self.modo_calibracao:
            # Na calibração mostra só o canal do eixo escolhido
            canais = {"X": ["ang_x"], "Y": ["ang_y"],
                      "Z": ["ang_z"], "ALT": ["alt"]}.get(
                          self.eixo_pid, ["ang_x"])
            titulo = f"Calibração PID: {self.eixo_pid}"
        else:
            # Na operação mostra os três ângulos e, se ativa, a altitude
            canais = ["ang_x", "ang_y", "ang_z"]
            if self.altitude_pid_ativa:
                canais.append("alt_secondary")
            titulo = "Operação: atitude" + (" e altitude" if self.altitude_pid_ativa else "")

        # Esconde tudo e mostra apenas os canais escolhidos (a referência sempre aparece)
        for linha in self.linhas.values():
            linha.set_visible(False)
        self.linha_sp.set_visible(True)
        self.ax_alt.set_visible("alt_secondary" in canais)
        for canal in canais:
            self.linhas[canal].set_visible(True)

        # Quando o canal é altitude, o eixo principal passa a mostrar metros
        if "alt" in canais:
            self.ax.set_ylabel("Altitude (m)", fontsize=10, color="#374151")
            self.ax_alt.set_visible(False)
        else:
            self.ax.set_ylabel("Ângulo (°)", fontsize=10, color="#374151")

        self.ax.set_title(titulo, fontsize=12, color="#111827", pad=12)
        self.lbl_titulo_grafico.configure(text=titulo)
        # Legenda só com as linhas visíveis
        handles = [linha for linha in self.linhas.values() if linha.get_visible()]
        if self.linha_sp.get_visible():
            handles.append(self.linha_sp)
        self.ax.legend(
            handles, [linha.get_label() for linha in handles],
            loc="upper right", frameon=True, fontsize=9,
            facecolor="#FFFFFF", edgecolor="#D1D5DB",
        )
        self._plot_dirty = True
        if hasattr(self, "canvas"):
            self.canvas.draw_idle()

    # ---- Desenho do gráfico ----

    # Redesenha a cada 150 ms, mas só quando há dados novos e a janela está visível.
    def _loop_desenho(self):
        if not self.winfo_exists():
            return
        if self._plot_dirty and self.winfo_viewable():
            self._atualizar_plot()
        self.after(150, self._loop_desenho)

    # Atualiza os dados das linhas com as amostras atuais e recalcula a escala.
    def _atualizar_plot(self):
        if len(self.xs) < 2: # precisa de pelo menos dois pontos
            self._plot_dirty = False
            return

        xs = self.xs
        # Mapeia cada linha para o campo de dado correspondente
        chaves_linha = {
            "ang_x": "ang_x", "ang_y": "ang_y", "ang_z": "ang_z",
            "alt": "alt", "alt_secondary": "alt",
        }
        for chave_linha, chave_dado in chaves_linha.items():
            self.linhas[chave_linha].set_data(
                xs, [amostra[chave_dado] for amostra in self.amostras],
            )
        # Referência calculada para os mesmos instantes das medições
        self.linha_sp.set_data(xs, gerar_referencia(xs, self.resposta, self.amplitude,
                                                    self.periodo, self.xbase,
                                                    self.inicio_referencia))
        # Onda quadrada usa degraus; as demais, linhas contínuas
        self.linha_sp.set_drawstyle("steps-post" if self.resposta == "Quadrada" else "default")
        # Ajusta a escala só aos dados visíveis
        self.ax.relim(visible_only=True)
        self.ax.autoscale_view()
        self.ax_alt.relim(visible_only=True)
        self.ax_alt.autoscale_view()
        self.canvas.draw_idle()
        self._plot_dirty = False