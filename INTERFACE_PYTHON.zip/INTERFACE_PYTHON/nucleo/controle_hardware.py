# nucleo/controle_hardware.py
import subprocess
import math


# Lê os sticks de um controle físico através de um executável externo (controle.exe).
# O executável escreve uma linha por leitura, no formato "lx,ly,rx,ry", e este módulo
# converte esses valores em comandos de roll, pitch, yaw e throttle para o drone.
class ControleHardware:
    def __init__(self, caminho_exe, max_roll, max_pitch, max_yaw,
                 stick_min=-1000, stick_max=1000, max_throttle=1.0,
                 controle_deadzone=0.035,
                 controle_expo=0.25):
        # Recebe os parâmetros globais vindos de "INTERFACE_PYTHON/config"
        self.caminho_exe = caminho_exe      # caminho do executável do controle
        self.max_roll = max_roll            # valor máximo de roll (inclinação lateral)
        self.max_pitch = max_pitch          # valor máximo de pitch (inclinação frontal)
        self.max_yaw = max_yaw              # valor máximo de yaw (rotação)
        self.stick_min = stick_min          # menor valor bruto que o stick pode enviar
        self.stick_max = stick_max          # maior valor bruto que o stick pode enviar
        self.max_throttle = max_throttle    # valor máximo do throttle normalizado
        # Zona morta: pequena faixa central em que o stick é tratado como zero.
        # Limitada entre 0 e 0.25 para não ficar grande demais.
        self.controle_deadzone = max(0.0, min(0.25, controle_deadzone))
        # Expo: curva que deixa o centro mais suave. Limitada entre 0 e 1.
        self.controle_expo = max(0.0, min(1.0, controle_expo))
        self.processo = None                # processo do controle.exe (None até iniciar)

    # Inicia o controle.exe como subprocesso, capturando sua saída padrão em texto.
    # Retorna (sucesso, mensagem).
    def iniciar(self):
        try:
            self.processo = subprocess.Popen(
                [self.caminho_exe],
                stdout=subprocess.PIPE,      # lê a saída do executável
                stderr=subprocess.STDOUT,    # erros do executável também vão para a saída
                bufsize=1,                   # buffer de linha
                text=True                    # trabalha com strings, não bytes
            )
            return True, f"Controle iniciado: {self.caminho_exe}"
        except Exception as e:
            self.processo = None
            return False, f"Erro ao abrir controle.exe: {e}"

    # Converte um valor de uma faixa para outra (regra de três linear).
    # O valor de entrada é limitado à faixa de entrada antes da conversão.
    def _mapear(self, valor, entrada_min, entrada_max, saida_min, saida_max):
        valor = max(entrada_min, min(entrada_max, valor))
        return (valor - entrada_min) * (saida_max - saida_min) / (entrada_max - entrada_min) + saida_min

    # Converte o valor bruto de um stick em um comando para um eixo:
    #  1. normaliza para a faixa -1 a 1;
    #  2. aplica a zona morta (valores pequenos viram zero);
    #  3. aplica a curva expo (mais suave perto do centro);
    #  4. multiplica pelo limite do eixo e mantém o sinal original.
    def _mapear_eixo(self, valor, limite):
        normalizado = self._mapear(valor, self.stick_min, self.stick_max, -1.0, 1.0)
        magnitude = abs(normalizado)
        # Dentro da zona morta, o comando é zero
        if magnitude <= self.controle_deadzone:
            return 0.0
        # Reescala para que o início da faixa útil comece em zero (sem salto)
        magnitude = (magnitude - self.controle_deadzone) / (1.0 - self.controle_deadzone)
        # Mistura linear com a curva cúbica, conforme o fator expo
        magnitude = (1.0 - self.controle_expo) * magnitude + self.controle_expo * magnitude ** 3
        return math.copysign(magnitude * limite, normalizado)

    # Lê uma linha do controle.exe e devolve (roll, pitch, yaw, throttle).
    # Retorna None quando não há dado novo, a linha está mal formada ou algum valor é inválido.
    def ler_comandos(self):
        # Sem processo ou sem saída disponível: nada a ler
        if self.processo is None or self.processo.stdout is None:
            return None

        # Processo terminou e a saída já foi fechada: nada a ler
        if self.processo.poll() is not None and self.processo.stdout.closed:
            return None

        # Lê no máximo 256 caracteres da linha (evita travar com linhas enormes)
        linha = self.processo.stdout.readline(256)
        if not linha:
            return None

        # Esperado: quatro valores separados por vírgula (lx, ly, rx, ry)
        partes = linha.strip().split(",")
        if len(partes) != 4:
            return None

        try:
            lx = float(partes[0])   # stick esquerdo, horizontal (yaw)
            ly = float(partes[1])   # stick esquerdo, vertical (throttle)
            rx = float(partes[2])   # stick direito, horizontal (roll)
            ry = float(partes[3])   # stick direito, vertical (pitch)

            # Rejeita NaN e infinito
            if not all(math.isfinite(valor) for valor in (lx, ly, rx, ry)):
                return None

            # Converte cada stick no comando correspondente
            roll = self._mapear_eixo(rx, self.max_roll)
            pitch = self._mapear_eixo(ry, self.max_pitch)
            yaw = self._mapear_eixo(lx, self.max_yaw)
            # Throttle não tem zona morta nem sinal: vai de 0 até max_throttle
            throttle = self._mapear(ly, self.stick_min, self.stick_max,
                                    0.0, self.max_throttle)

            return roll, pitch, yaw, throttle

        except ValueError:
            return None

    # Encerra o controle.exe com segurança: tenta terminar, espera 2 s,
    # e se não responder, força o encerramento. Também fecha a saída e limpa o processo.
    def fechar(self):
        if self.processo:
            if self.processo.poll() is None:          # ainda está rodando
                self.processo.terminate()             # pede para encerrar
                try:
                    self.processo.wait(timeout=2)     # espera até 2 s
                except subprocess.TimeoutExpired:
                    self.processo.kill()              # não respondeu: força
                    self.processo.wait()
            if self.processo.stdout is not None:
                self.processo.stdout.close()
            self.processo = None