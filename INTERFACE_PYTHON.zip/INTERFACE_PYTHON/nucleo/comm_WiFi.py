import math
import re
import socket
import threading
import time

from .telemetria import FRAME_FIELDS, _recuperar_frames_colados


# Confere se um campo tem o formato de número com uma casa decimal (ex.: "45.6").
# Usado para reconhecer o último campo de um frame quando o LF não chegou.
_PROGRESSO_COMPLETO = re.compile(r"-?\d+\.\d")


# Cliente TCP que conversa com o ESP32: envia comandos (setpoints, PID, referências,
# calibração, desarme) e recebe a telemetria em linhas de texto.
class ESPCom:
    def __init__(self, ip, porta, timeout=2.0):
        self.ip = ip                          # IP do ESP32
        self.porta = porta                    # porta TCP do ESP32
        self.timeout = timeout                # timeout padrão das operações de socket
        self.sock = None                      # socket atual (None quando desconectado)
        self.buffer = bytearray()             # bytes recebidos ainda não convertidos em linha
        self._lock = threading.RLock()        # protege sock e buffer entre threads
        self._fechando = False                # True após finalizar/desarmar: bloqueia reconexões
        self._ultima_tentativa = 0.0          # instante (monotonic) da última tentativa de conexão
        self._intervalo_reconexao = 1.0       # espera mínima entre tentativas automáticas
        self._ultima_linha = 0.0              # instante da última linha de telemetria válida
        self._limite_sem_linha = 10.0         # segundos sem linha válida até reiniciar a sessão
        self._sem_linha_reportado = False     # evita repetir o aviso de "sem linha"
        self._bytes_desde_linha = 0           # bytes recebidos desde a última linha válida

    # Abre a conexão TCP com o ESP32.
    # forcar=True ignora o bloqueio de finalização e o intervalo entre tentativas.
    # Retorna True se já estiver conectado ou se a conexão for estabelecida.
    def conectar(self, forcar=False):
        with self._lock:
            if forcar:
                # Um início explícito é a única ação que reativa conexões após finalizar_comunicacao()
                self._fechando = False
            elif self._fechando:
                return False

            if self.sock is not None:
                return True

            # Respeita o intervalo entre tentativas automáticas
            agora = time.monotonic()
            if not forcar and agora - self._ultima_tentativa < self._intervalo_reconexao:
                return False
            self._ultima_tentativa = agora

            novo_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                # Dá mais tempo ao handshake: no Wi-Fi do ESP32 o SYN/ACK pode se perder
                # e 2 s era pouco para recuperar a conexão.
                novo_sock.settimeout(max(self.timeout, 5.0))
                novo_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)   # desativa Nagle
                novo_sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)   # keepalive do TCP
                novo_sock.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, 65536)  # buffer de recepção
                novo_sock.connect((self.ip, self.porta))
                novo_sock.settimeout(self.timeout)                                # timeout normal depois
            except OSError as erro:
                novo_sock.close()
                print(f"Falha ao conectar em {self.ip}:{self.porta}: {erro}")
                return False

            # Conexão estabelecida: zera o estado de recepção da nova sessão
            self.sock = novo_sock
            self.buffer.clear()
            self._ultima_linha = time.monotonic()
            self._sem_linha_reportado = False
            self._bytes_desde_linha = 0
            print(f"Conectado ao ESP32 em {self.ip}:{self.porta}")
            return True

    # Envia o setpoint de voo: roll, pitch, yaw (graus) e throttle (0 a 1).
    # Valida faixas e valores finitos antes de enviar. Retorna True se enviou.
    def enviar_setpoint(self, roll, pitch, yaw, throttle):
        valores = (roll, pitch, yaw, throttle)
        try:
            valores = tuple(float(valor) for valor in valores)
        except (TypeError, ValueError, OverflowError):
            return False
        if not all(math.isfinite(valor) for valor in valores):
            return False

        # Limites de segurança: inclinação até 45°, yaw até 180°, throttle entre 0 e 1
        roll, pitch, yaw, throttle = valores
        if abs(roll) > 45.0 or abs(pitch) > 45.0 or abs(yaw) > 180.0 or not 0.0 <= throttle <= 1.0:
            return False

        if not self.conectar():
            return False

        try:
            msg = f"{roll:.2f},{pitch:.2f},{yaw:.2f},{throttle:.3f}\n"
            with self._lock:
                sock = self.sock
                if sock is None:
                    return False
                sock.sendall(msg.encode("ascii"))
            return True
        except OSError as erro:
            # Só fecha o socket se ainda for o mesmo (outra thread pode ter trocado)
            with self._lock:
                ainda_atual = self.sock is sock
            if ainda_atual:
                print(f"Falha ao enviar comando ao ESP32: {erro}")
                self._fechar_socket(sock, reconectar_imediato=True)
            return False

    # Pede o desarme explícito do controlador de voo e bloqueia novas reconexões
    # automáticas até um início forçado.
    def desarmar(self):
        """Request an explicit flight-controller disarm on the current session."""
        with self._lock:
            self._fechando = True
            sock = self.sock
            if sock is None:
                return False
            try:
                sock.sendall(b"DISARM\n")
                return True
            except OSError as erro:
                print(f"Falha ao enviar comando de desarme ao ESP32: {erro}")
                self._fechar_socket(sock, reconectar_imediato=False)
                return False

    # Envia os ganhos PID (kp, ki, kd) para um eixo ("ALL", "X", "Y", "Z" ou "ALT").
    # Valida as faixas permitidas antes de enviar.
    def enviar_pid(self, kp, ki, kd, eixo="ALL"):
        try:
            kp, ki, kd = (float(valor) for valor in (kp, ki, kd))
        except (TypeError, ValueError, OverflowError):
            return False
        if not all(math.isfinite(valor) for valor in (kp, ki, kd)):
            return False
        if not 0.0 <= kp <= 10.0 or not 0.0 <= ki <= 1.0 or not 0.0 <= kd <= 2.0:
            return False
        if eixo not in ("ALL", "X", "Y", "Z", "ALT"):
            return False
        return self._enviar_linha(f"PID,{eixo},{kp:.4f},{ki:.4f},{kd:.4f}\n")

    # Envia o modo de operação: se é calibração, qual eixo e se o modo altitude está ativo.
    def enviar_modo_pid(self, calibracao, eixo, altitude):
        if eixo not in ("X", "Y", "Z", "ALT"):
            return False
        return self._enviar_linha(
            f"MODE,{int(bool(calibracao))},{eixo},{int(bool(altitude))}\n"
        )

    # Envia uma referência de movimento (constante, senoidal, quadrada ou triangular)
    # para um eixo. Valida o tipo, o período e se amplitude + offset cabem no limite do eixo.
    def enviar_referencia(self, tipo, amplitude, periodo, offset, eixo="X"):
        # Converte os nomes da interface para os códigos usados pelo ESP32
        tipos = {"Constante": "CONST", "Senoidal": "SENO", "Quadrada": "QUAD", "Triangular": "TRI"}
        try:
            amplitude, periodo, offset = (float(valor) for valor in (amplitude, periodo, offset))
        except (TypeError, ValueError, OverflowError):
            return False
        if (tipo not in tipos or eixo not in ("X", "Y", "Z", "ALT") or
                not all(math.isfinite(valor) for valor in (amplitude, periodo, offset))):
            return False
        # Altitude tem limite de 10; os eixos de atitude, 45
        limite = 10.0 if eixo == "ALT" else 45.0
        if periodo < 0.5 or periodo > 300.0 or abs(amplitude) + abs(offset) > limite:
            return False
        return self._enviar_linha(
            f"REF,{eixo},{tipos[tipo]},{amplitude:.3f},{periodo:.3f},{offset:.3f}\n"
        )

    # Desliga a referência ativa no ESP32.
    def desativar_referencia(self):
        return self._enviar_linha("REF_OFF\n")

    # Envia uma linha de texto ao ESP32, conectando antes se necessário.
    # Em caso de erro de envio, fecha o socket para que a próxima tentativa reconecte.
    def _enviar_linha(self, msg):
        if not self.conectar():
            return False
        sock = None
        try:
            with self._lock:
                sock = self.sock
                if sock is None:
                    return False
                sock.sendall(msg.encode("ascii"))
            return True
        except OSError as erro:
            with self._lock:
                ainda_atual = self.sock is sock
            if ainda_atual:
                print(f"Falha ao enviar comando ao ESP32: {erro}")
                self._fechar_socket(sock, reconectar_imediato=True)
            return False

    # Envia o comando CAL_MAG para iniciar a calibração do magnetômetro no ESP32.
    def solicitar_calibracao_magnetometro(self):
        if not self.conectar():
            return False

        sock = None
        try:
            with self._lock:
                sock = self.sock
                if sock is None:
                    return False
                sock.sendall(b"CAL_MAG\n")
            return True
        except OSError as erro:
            print(f"Falha ao solicitar calibracao do magnetometro: {erro}")
            if sock is not None:
                self._fechar_socket(sock)
            return False

    # Devolve uma linha de telemetria, se houver uma completa.
    # Primeiro tenta extrair do buffer; só depois lê novos bytes do socket.
    # Retorna None quando ainda não há linha completa.
    def receber_dados(self):
        if not self.conectar():
            return None

        with self._lock:
            sock = self.sock
            linha = self._extrair_linha()
        if linha is not None:
            return linha
        if sock is None:
            return None
        # Se estiver muito tempo sem linha válida, reinicia a sessão
        if self._reiniciar_sessao_se_ociosa(sock):
            return None

        try:
            dados = sock.recv(1024)
            # recv vazio significa que o ESP32 fechou a conexão
            if not dados:
                print("Conexão TCP encerrada pelo ESP32.")
                self._fechar_socket(sock)
                return None

            with self._lock:
                self.buffer.extend(dados)
                self._bytes_desde_linha += len(dados)
                # Proteção contra crescimento infinito: se o buffer passou de 8 KB,
                # descarta tudo até a última quebra de linha (ou tudo, se não houver)
                if len(self.buffer) > 8192:
                    ultima_linha = self.buffer.rfind(b"\n")
                    if ultima_linha >= 0:
                        del self.buffer[:ultima_linha + 1]
                    else:
                        self.buffer.clear()
                    print("Buffer TCP excedeu o limite; dados antigos descartados.")
                linha = self._extrair_linha()
            if linha is None:
                self._reiniciar_sessao_se_ociosa(sock)
            return linha
        except socket.timeout:
            # Nenhum dado chegou no tempo limite: verifica se a sessão ficou ociosa
            self._reiniciar_sessao_se_ociosa(sock)
            return None
        except OSError as erro:
            with self._lock:
                ainda_atual = self.sock is sock
            if ainda_atual:
                print(f"Falha ao receber telemetria: {erro}")
                self._fechar_socket(sock, reconectar_imediato=True)
            return None

    # Se o socket está conectado mas nenhuma linha válida chegou por
    # _limite_sem_linha segundos, fecha a sessão para forçar uma nova conexão.
    # Retorna True se a sessão foi reiniciada.
    def _reiniciar_sessao_se_ociosa(self, sock):
        with self._lock:
            if (self.sock is not sock or self._sem_linha_reportado or
                    time.monotonic() - self._ultima_linha < self._limite_sem_linha):
                return False
            bytes_buffer = self._bytes_desde_linha
            tamanho_buffer = len(self.buffer)
            # Amostra do início do buffer, para diagnóstico no log
            amostra = bytes(self.buffer[:96]).decode("ascii", errors="replace")
            self._sem_linha_reportado = True
            # Nada chegou ainda: o ESP32 pode estar só demorando para começar a enviar
            if bytes_buffer == 0 and tamanho_buffer == 0:
                print("TCP conectado, mas o ESP32 ainda não enviou telemetria; mantendo a sessão aberta.")
                return False

        print(
            f"Sem frame TCP completo por {self._limite_sem_linha:.1f} s; "
            f"bytes_recebidos={bytes_buffer}, buffer={tamanho_buffer}, "
            f"amostra={amostra!r}; reiniciando a sessão TCP."
        )
        self._fechar_socket(sock, reconectar_imediato=True)
        return True

    # Extrai uma linha completa do buffer.
    # Caminho normal: procura o '\n'. Caminho de contingência: se o LF não chegou,
    # aceita o buffer como frame completo quando tem 15 campos e o último é
    # um progresso com uma casa decimal, ou separa frames colados.
    # Retorna a linha decodificada ou None.
    def _extrair_linha(self):
        separador = self.buffer.find(b"\n")
        if separador >= 0:
            # Caminho normal: linha terminada em '\n' (remove '\r' do fim, se houver)
            linha = bytes(self.buffer[:separador]).rstrip(b"\r")
            del self.buffer[:separador + 1]
            try:
                linha_decodificada = linha.decode("ascii")
            except UnicodeDecodeError:
                return None
        else:
            # Contingência: alguns firmwares deixam de enviar o LF.
            # O protocolo atual tem 15 campos e o último (progresso) sempre tem uma casa decimal.
            try:
                bruto = self.buffer.decode("ascii")
            except UnicodeDecodeError:
                return None

            partes = bruto.split(",")
            # Exatamente 15 campos com progresso válido: frame completo sem LF
            if len(partes) == FRAME_FIELDS and _PROGRESSO_COMPLETO.fullmatch(partes[-1]):
                linha_decodificada = bruto
                self.buffer.clear()
            # Mais de 15 campos: pode haver frames colados. Separa e guarda o restante
            elif len(partes) > FRAME_FIELDS:
                recuperadas = _recuperar_frames_colados(partes, manter_todos=True)
                if (len(recuperadas) < FRAME_FIELDS or
                        not _PROGRESSO_COMPLETO.fullmatch(recuperadas[FRAME_FIELDS - 1])):
                    return None
                linha_decodificada = ",".join(recuperadas[:FRAME_FIELDS])
                restante = ",".join(recuperadas[FRAME_FIELDS:])
                self.buffer = bytearray(restante.encode("ascii"))
            else:
                # Frame ainda incompleto: espera mais bytes
                return None

        # Linha válida: atualiza os marcadores de atividade
        self._ultima_linha = time.monotonic()
        self._sem_linha_reportado = False
        self._bytes_desde_linha = 0
        return linha_decodificada

    # Fecha o socket atual e limpa o buffer. Só age se o socket ainda for o atual.
    # Com reconectar_imediato=True, a próxima chamada de conectar() não espera o intervalo.
    def _fechar_socket(self, sock, reconectar_imediato=False):
        with self._lock:
            if self.sock is not sock:
                return
            self.sock = None
            self.buffer.clear()
            if reconectar_imediato:
                # Permite que a próxima leitura abra uma conexão nova.
                # Se ela falhar, conectar() mantém o intervalo normal entre tentativas.
                self._ultima_tentativa = 0.0
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            sock.close()

    # Encerra a comunicação de forma definitiva: bloqueia reconexões automáticas
    # e fecha o socket. Só um conectar(forcar=True) reativa a comunicação.
    def fechar(self):
        with self._lock:
            self._fechando = True
            sock = self.sock
            self.sock = None
            self.buffer.clear()

        if sock is not None:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            sock.close()