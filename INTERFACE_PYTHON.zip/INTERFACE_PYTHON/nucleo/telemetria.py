import math
import re


# Regex que detecta dois números colados sem separador (falta de LF entre frames).
# Ex.: "1.23-45.67" -> grupo 1 = "1.2", grupo 2 = "3-45.67"... ajustado ao formato real do campo.
_FIM_E_INICIO_COLADOS = re.compile(r"(-?\d+\.\d)(-?\d+\.\d{2})")
FRAME_FIELDS = 15  # Quantidade de campos esperados em cada frame de telemetria


# Separa frames de 15 campos quando faltou o '\n' entre dois frames consecutivos.
# Se um campo na posição final de um frame contém o fim do frame anterior colado
# com o início do próximo, ele é dividido em dois campos.
# Se manter_todos for False e houver mais de um frame completo, retorna só o mais recente.
def _recuperar_frames_colados(partes, manter_todos=False):
    """Separa frames de 15 campos quando faltou o LF entre dois frames."""
    recuperadas = []
    for parte in partes:
        # Só procura a junção quando o próximo campo seria o último de um frame
        if len(recuperadas) % FRAME_FIELDS == FRAME_FIELDS - 1:
            junção = _FIM_E_INICIO_COLADOS.fullmatch(parte)
            if junção:
                recuperadas.extend(junção.groups())  # adiciona as duas partes separadas
                continue
        recuperadas.append(parte)

    # Se pediu todos os frames, devolve a lista completa
    if manter_todos:
        return recuperadas
    # Caso contrário, havendo mais de um frame completo, mantém apenas o último
    # (a interface mostra o mais recente; o receptor TCP pode precisar guardar todos)
    if len(recuperadas) >= FRAME_FIELDS * 2 and len(recuperadas) % FRAME_FIELDS == 0:
        return recuperadas[-FRAME_FIELDS:]
    return recuperadas


# Interpreta uma string de telemetria vinda do ESP32 (campos separados por vírgula).
# Retorna uma tupla (mensagem, dados):
#  - mensagem: texto para exibir ou descrever um erro;
#  - dados: dicionário com os valores tratados, ou None em caso de falha.
def processar_dados_esp(dados_brutos):
    try:
        # Remove espaços/quebras das pontas e separa os campos por vírgula
        partes = dados_brutos.strip().split(",")
        # Se há mais campos que um frame, tenta recuperar frames colados
        if len(partes) > FRAME_FIELDS:
            partes = _recuperar_frames_colados(partes)
        # Ainda não tem a quantidade certa de campos: formato inválido
        if len(partes) != FRAME_FIELDS:
            return f"Formato não reconhecido: {dados_brutos}", None

        # Converte todos os campos para float
        valores = [float(parte) for parte in partes]
        # Rejeita NaN e infinito
        if not all(math.isfinite(valor) for valor in valores):
            return f"Telemetria contém valor inválido: {dados_brutos}", None

        # Valida os indicadores (campos 10 a 14) contra os valores permitidos:
        #  10 = sistema pronto (0/1)
        #  11 = link ok (0/1)
        #  12 = estado de voo (0 a 2)
        #  13 = status do magnetômetro (0 a 5)
        #  14 = progresso do magnetômetro (0 a 100)
        if (valores[10] not in (0.0, 1.0) or valores[11] not in (0.0, 1.0) or
                valores[12] not in (0.0, 1.0, 2.0) or
                valores[13] not in (0.0, 1.0, 2.0, 3.0, 4.0, 5.0) or
                not 0.0 <= valores[14] <= 100.0):
            return f"Indicador de telemetria inválido: {dados_brutos}", None

        # Monta o dicionário com nomes legíveis para cada campo
        dados = {
            "sistema_pronto": bool(valores[10]),
            "link_ok": bool(valores[11]),
            "estado_voo": int(valores[12]),
            "ang_x": valores[0],          # ângulo em X
            "ang_y": valores[1],          # ângulo em Y
            "ang_z": valores[2],          # ângulo em Z
            "alt":   valores[3],          # altitude (filtro de Kalman), em metros
            "vel":   valores[4],          # velocidade (filtro de Kalman), em m/s
            "temp":  valores[5],          # temperatura do barômetro, em °C
            "m1":    valores[6],          # potência do motor 1
            "m2":    valores[7],          # potência do motor 2
            "m3":    valores[8],          # potência do motor 3
            "m4":    valores[9],          # potência do motor 4
            "mag_status": int(valores[13]),
            "mag_progress": valores[14],
        }

        # Link caiu: retorna aviso, mas ainda devolve os dados para quem precisar
        if not dados["link_ok"]:
            return "ESP32 sem telemetria válida", dados

        # Mensagem formatada para exibição na interface
        msg = (
            f"Ângulos -> X:{dados['ang_x']:.2f} | Y:{dados['ang_y']:.2f} | Z:{dados['ang_z']:.2f} | "
            f"Kalman -> Alt:{dados['alt']:.3f}m | Vel:{dados['vel']:.3f}m/s | "
            f"Barômetro -> Temp:{dados['temp']:.2f}°C | "
            f"Motores -> M1:{dados['m1']:.0f} | M2:{dados['m2']:.0f} | M3:{dados['m3']:.0f} | M4:{dados['m4']:.0f}"
        )

        return msg, dados

    # Erro de conversão numérica (float inválido ou estouro)
    except (ValueError, OverflowError):
        return f"conversão invalida: {dados_brutos}", None