import threading
import time

import cv2
from PIL import Image, ImageTk


# Captura frames de uma câmera (por exemplo, um stream de rede) em uma thread separada,
# para que a interface nunca fique esperando a leitura do vídeo.
class Camera:
    def __init__(self, url):
        self.url = url                    # endereço do stream (RTSP, HTTP, etc.)
        self.cap = None                   # objeto VideoCapture atual (None quando fechado)
        self._frame = None                # último frame capturado (formato BGR do OpenCV)
        self._erro = None                 # mensagem do último erro, se houver
        self._lock = threading.Lock()     # protege _frame e cap entre threads
        self._parar = threading.Event()   # sinaliza para a thread de captura encerrar
        self._thread = None               # thread de captura

    # Inicia a thread de captura. Se ela já estiver rodando, não faz nada.
    def iniciar(self):
        if self._thread is not None and self._thread.is_alive():
            return True
        self._parar.clear()
        self._erro = None
        self._thread = threading.Thread(target=self._capturar, daemon=True)
        self._thread.start()
        return True

    # Abre o stream com timeouts de abertura (2 s) e de leitura (1 s).
    # Se a abertura com parâmetros falhar, tenta sem eles.
    # Retorna o VideoCapture aberto ou None.
    def _abrir_captura(self):
        captura = cv2.VideoCapture()
        parametros = [
            getattr(cv2, "CAP_PROP_OPEN_TIMEOUT_MSEC", 53), 2000,   # tempo máximo para abrir
            getattr(cv2, "CAP_PROP_READ_TIMEOUT_MSEC", 54), 1000,   # tempo máximo para ler
        ]
        try:
            aberto = captura.open(self.url, cv2.CAP_ANY, parametros)
        except (TypeError, cv2.error):
            # Versões do OpenCV que não aceitam parâmetros na abertura
            aberto = captura.open(self.url)
        if not aberto:
            # Segunda tentativa, sem parâmetros
            captura.release()
            captura = cv2.VideoCapture(self.url)
            if not captura.isOpened():
                captura.release()
                return None
        # Buffer de 1 quadro: sempre lê o mais recente, evitando atraso acumulado
        captura.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        return captura

    # Corpo da thread: abre o stream e lê frames a cerca de 15 por segundo
    # até que fechar() seja chamado ou ocorra um erro.
    def _capturar(self):
        try:
            captura = self._abrir_captura()
        except Exception as erro:
            self._erro = str(erro)
            return
        if captura is None:
            self._erro = f"Não foi possível abrir {self.url}"
            return

        with self._lock:
            self.cap = captura

        intervalo_frame = 1.0 / 15.0          # intervalo alvo entre frames (15 FPS)
        proximo_frame = time.monotonic()
        while not self._parar.is_set():
            # Espera até o momento do próximo frame, mas acorda logo se for pedido para parar
            espera = proximo_frame - time.monotonic()
            if espera > 0 and self._parar.wait(espera):
                break
            try:
                ret, frame = captura.read()
            except cv2.error as erro:
                self._erro = str(erro)
                break
            proximo_frame = time.monotonic() + intervalo_frame
            if ret:
                # Guarda somente o frame mais recente
                with self._lock:
                    self._frame = frame
            else:
                # Leitura falhou: pequena pausa antes de tentar de novo
                time.sleep(0.02)

        # Encerramento: libera o stream e zera a referência, se ainda for a mesma
        captura.release()
        with self._lock:
            if self.cap is captura:
                self.cap = None

    # Devolve a mensagem do último erro ocorrido na captura (ou None).
    def erro(self):
        return self._erro

    # Converte o último frame para um PhotoImage do Tkinter, redimensionado para
    # largura x altura. Retorna None se ainda não houver frame.
    def ler_frame(self, largura, altura):
        # Copia o frame sob o lock, para não disputar com a thread de captura
        with self._lock:
            frame = None if self._frame is None else self._frame.copy()
        if frame is None:
            return None

        frame = cv2.resize(frame, (largura, altura))        # ajusta ao tamanho da tela
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # OpenCV usa BGR; Pillow usa RGB
        imagem = Image.fromarray(frame_rgb)
        return ImageTk.PhotoImage(imagem)

    # Para a thread de captura e descarta o último frame.
    # O join tem timeout curto, então a thread pode continuar por um instante após o retorno.
    def fechar(self):
        self._parar.set()
        if self._thread is not None:
            self._thread.join(timeout=0.1)
        with self._lock:
            self._frame = None